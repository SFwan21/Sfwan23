        document.addEventListener("DOMContentLoaded", function() {
            yall({
                observeChanges: true
            });
        });
		var pageEmbed = 0;
		var pageRoom = 1;
		var curPage = 'home';
		var loadPage = '';
		var bbfv = '?v=1.49';
		var rtlMode = '0';
		var logged = 0;
		var utk = '0';
